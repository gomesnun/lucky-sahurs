<h1 align="center">Lucky Verities</h1>

<p align="center">
  <b>An idle collecting game about Verities: little round creatures with big personalities.</b><br>
  Roll for pets from <i>Common</i> to <i>Transcendent</i>, stack income, rebirth for permanent power,
  and climb the global leaderboard — solo, on any desktop.
</p>

<p align="center">
  <a href="https://gomesnun.github.io/lucky-sahurs/website/"><b>🌐 Website &amp; live roll simulator</b></a> ·
  <a href="https://github.com/gomesnun/lucky-sahurs/releases/latest"><b>⬇ Download latest release</b></a> ·
  <a href="LEIA-ME.md"><b>🇵🇹 Versão portuguesa</b></a>
</p>

<p align="center">
  <img alt="Windows" src="https://img.shields.io/badge/Windows-.exe-0078D6?logo=windows&logoColor=white">
  <img alt="macOS" src="https://img.shields.io/badge/macOS-Apple%20Silicon%20%2B%20Intel-000000?logo=apple&logoColor=white">
  <img alt="Linux" src="https://img.shields.io/badge/Linux-x86__64-FCC624?logo=linux&logoColor=black">
  <img alt="Android" src="https://img.shields.io/badge/Android-7.0%2B-3DDC84?logo=android&logoColor=white">
  <img alt="Python" src="https://img.shields.io/badge/Python-3.10%2B-3776AB?logo=python&logoColor=white">
  <img alt="pygame-ce" src="https://img.shields.io/badge/pygame--ce-engine-green">
</p>

---

## What it is

Press **ROLL**. Get a pet. The rare ones pay better. The rarest one is a **1-in-500,000,000,000**.

| | |
|---|---|
| **11** rarity tiers | Common → Uncommon → Rare → Epic → Legendary → Mythic → Exotic → Secret → Divine → Cosmic → Transcendent |
| **22** collectible Verities | each with its own income curve |
| **3** mutations | Golden / Diamond / and the one you find yourself |
| **12** traits | permanent modifiers rolled on top of pets |
| **Milestones** | long-run reward tracks across every category |
| **Rebirths** | wipe progress, keep permanent multipliers |
| **Daily missions** | rotating objectives, offline earnings while you sleep |
| **Cloud saves** | 3 slots, Firebase-backed, optional account |
| **Leaderboard** | global ranking |
| **Languages** | English + Português |

Everything runs offline too — the account is optional.

---

## Install

Pick your platform. Fastest path is the prebuilt download; no Python needed.

### 🪟 Windows

1. Open the [latest release](https://github.com/gomesnun/lucky-sahurs/releases/latest).
2. Download `Lucky-Verities-Windows.exe`.
3. Double-click it. SmartScreen may warn about an unknown publisher → **More info → Run anyway** (the build is unsigned).


### 🍎 macOS (Apple Silicon &amp; Intel)

1. Open the [latest release](https://github.com/gomesnun/lucky-sahurs/releases/latest).
2. Download `Lucky-Verities-macOS-AppleSilicon.zip` (M1/M2/M3/M4) or `Lucky-Verities-macOS-Intel.zip`.
3. Unzip it, then **right-click the app → Open** the first time (the app is unsigned, so a plain double-click is blocked).

### 🐧 Linux

1. Open the [latest release](https://github.com/gomesnun/lucky-sahurs/releases/latest).
2. Download the Linux `.tar.gz` and extract it.
3. Make it runnable and start it:
   ```bash
   chmod +x "Lucky Verities"
   ./"Lucky Verities"
   ```
   The binary needs **glibc ≥ 2.39** (Ubuntu 24.04+, Fedora 40+, Mint 22+, Arch).

### 🤖 Android

Landscape, touch-first: tap to roll and to press buttons, drag to scroll a list, hardware **Back** closes the
open panel. Account, cloud saves and the leaderboard work the same as on desktop.

1. Open the [latest release](https://github.com/gomesnun/lucky-sahurs/releases/latest) on your phone.
2. Download `Lucky-Verities-Android.apk`.
3. Android will ask to allow installs from your browser — allow it, then tap **Install**. The APK is
   debug-signed, so Play Protect shows an "unknown app" warning: **More details → Install anyway**.

Minimum Android 7.0 (API 24), `arm64-v8a` + `armeabi-v7a`.

---

## License

All rights reserved unless stated otherwise. Ask before redistributing builds.
