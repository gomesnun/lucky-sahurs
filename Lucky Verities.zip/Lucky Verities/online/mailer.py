"""Envio do email com o código de verificação, através da Brevo (API de emails transacionais).

Não precisa de nenhuma biblioteca extra: fala com a Brevo por HTTPS (REST) com o urllib, tal como o
online/firebase.py fala com o Firebase. Para ativar: preenche a chave aqui em baixo (Brevo -> Settings ->
SMTP & API -> API Keys). Com a chave vazia, o jogo funciona à mesma, só que sem mandar emails.
"""

import json
import urllib.error
import urllib.request

from online.tls import ssl_context

BREVO_API_KEY = "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"
BREVO_ENDPOINT = "https://api.brevo.com/v3/smtp/email"
SENDER = {"name": "Lucky Verities", "email": "guilherme.can.gomes@gmail.com"}
MAIL_TIMEOUT = 10.0


class MailError(Exception):
    """Falha a mandar o email (rede, chave inválida, remetente não verificado, etc.)."""


def mailer_ready():
    return bool(BREVO_API_KEY.strip())


def send_verification_code(to_email, code):
    """Manda o código de 6 dígitos por email. Deve correr numa thread do Worker (é uma chamada de
    rede bloqueante), nunca no loop principal do jogo."""
    if not mailer_ready():
        raise MailError("email sending isn't configured (BREVO_API_KEY is empty)")

    subject = "O teu código Lucky Verities: %s" % code
    html = (
        "<div style=\"font-family:Arial,Helvetica,sans-serif;font-size:16px;color:#1a1a1a;"
        "max-width:420px;margin:0 auto\">"
        "<p>O teu código de verificação do <b>Lucky Verities</b> é:</p>"
        "<p style=\"font-size:34px;font-weight:bold;letter-spacing:8px;text-align:center;"
        "background:#f2f2f7;border-radius:10px;padding:16px 0;margin:18px 0\">%s</p>"
        "<p>Introduz este código no jogo para confirmares o teu email. O código expira em 10 minutos.</p>"
        "<p style=\"color:#777;font-size:13px\">Se não pediste isto, ignora este email — a tua conta "
        "continua segura.</p>"
        "</div>" % code
    )
    text = ("O teu código de verificação do Lucky Verities é: %s\n"
            "Introduz este código no jogo para confirmares o teu email. Expira em 10 minutos.\n"
            "Se não pediste isto, ignora este email." % code)
    body = {
        "sender": SENDER,
        "to": [{"email": to_email}],
        "subject": subject,
        "htmlContent": html,
        "textContent": text,
    }
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(BREVO_ENDPOINT, data=data, method="POST", headers={
        "accept": "application/json",
        "content-type": "application/json",
        "api-key": BREVO_API_KEY,
    })
    try:
        with urllib.request.urlopen(req, timeout=MAIL_TIMEOUT, context=ssl_context()) as resp:
            resp.read()
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8")).get("message", str(e))
        except (ValueError, AttributeError):
            msg = str(e)
        raise MailError(msg)
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise MailError(str(e))
